#!/usr/bin/env bash
# ╔══════════════════════════════════════════════════════════════════════╗
# ║  install.sh  ·  adds the zsh layer (autosuggest, colors, fzf, ...)   ║
# ╚══════════════════════════════════════════════════════════════════════╝
#
# What it does, in order:
#   1. installs missing helper tools with your package manager (asks first)
#   2. downloads five zsh plugins into ~/.local/share/ghostty-zsh/plugins
#   3. copies ghostty.zsh and starship.toml to ~/.config/ghostty-zsh
#   4. adds one guarded block to ~/.zshrc (the old file is backed up first)
#
# It only installs what is missing, so running it again is safe.
#
#   ./install.sh               interactive
#   ./install.sh --dry-run     show every step, change nothing
#   ./install.sh --yes         no questions
#   ./install.sh --no-packages skip step 1 (plugins and config only)
#   ./install.sh --uninstall   remove the block from ~/.zshrc
#   ./install.sh --help
#
# Works on macOS (Homebrew) and Linux (apt, dnf, pacman, zypper, Homebrew).

set -euo pipefail

SCRIPT_DIR=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)
CFG_DIR=${XDG_CONFIG_HOME:-$HOME/.config}/ghostty-zsh
DATA_DIR=${XDG_DATA_HOME:-$HOME/.local/share}/ghostty-zsh
PLUG_DIR=$DATA_DIR/plugins
ZSHRC=${ZDOTDIR:-$HOME}/.zshrc
MARK_BEGIN='# >>> ghostty-zsh >>>'
MARK_END='# <<< ghostty-zsh <<<'

DRY=0
ASSUME_YES=0
DO_PKGS=1
DO_PLUGINS=1
DO_STARSHIP=1
UNINSTALL=0
PURGE=0

# ─── output helpers ─────────────────────────────────────────────────────
if [ -t 1 ] && [ -z "${NO_COLOR:-}" ]; then
  B=$'\033[1m'; D=$'\033[2m'; R=$'\033[31m'; G=$'\033[32m'; Y=$'\033[33m'; C=$'\033[36m'; Z=$'\033[0m'
else
  B=''; D=''; R=''; G=''; Y=''; C=''; Z=''
fi
step() { printf '\n%s▸ %s%s\n' "$B$C" "$1" "$Z"; }
ok()   { printf '  %s✔%s %s\n' "$G" "$Z" "$1"; }
note() { printf '  %s%s%s\n' "$D" "$1" "$Z"; }
warn() { printf '  %s!%s %s\n' "$Y" "$Z" "$1" >&2; }
die()  { printf '%sError:%s %s\n' "$R" "$Z" "$1" >&2; exit 1; }

# Past tense when done, "would ..." in a dry run:  report downloaded download thing
report() {
  if [ "$DRY" = 1 ]; then note "would $2 $3"; else ok "$1 $3"; fi
}

usage() {
  cat <<'EOT'
Usage: install.sh [options]

  (no options)     ask before changing anything
  -n, --dry-run    show every step, change nothing
  -y, --yes        answer yes to every question
  --no-packages    skip the helper tools (plugins and config only)
  --no-plugins     skip the plugin downloads
  --no-starship    never offer the Starship installer
  --uninstall      remove the block from ~/.zshrc (keeps the downloaded files)
  --purge          like --uninstall, and delete the downloaded files too
  -h, --help       this text

Needs bash and, for the plugins, git. Works on macOS (Homebrew) and on Linux
(apt, dnf, pacman, zypper or Homebrew). Safe to run again.
EOT
}

# Run a command, or only print it with --dry-run.
run() {
  if [ "$DRY" = 1 ]; then
    printf '  %s[dry-run]%s' "$D" "$Z"
    printf ' %q' "$@"
    printf '\n'
    return 0
  fi
  "$@"
}

# Ask a yes/no question. --yes and --dry-run answer yes; with no terminal the answer is no.
ask() {
  if [ "$ASSUME_YES" = 1 ] || [ "$DRY" = 1 ]; then return 0; fi
  if [ ! -t 0 ]; then return 1; fi
  local reply
  printf '  %s?%s %s [Y/n] ' "$B" "$Z" "$1"
  read -r reply || return 1
  case $reply in ''|y|Y|yes|YES) return 0 ;; *) return 1 ;; esac
}

have() { command -v "$1" >/dev/null 2>&1; }

# ─── arguments ──────────────────────────────────────────────────────────
for arg in "$@"; do
  case $arg in
    -n|--dry-run)    DRY=1 ;;
    -y|--yes)        ASSUME_YES=1 ;;
    --no-packages)   DO_PKGS=0 ;;
    --no-plugins)    DO_PLUGINS=0 ;;
    --no-starship)   DO_STARSHIP=0 ;;
    --uninstall)     UNINSTALL=1 ;;
    --purge)         UNINSTALL=1; PURGE=1 ;;
    -h|--help)       usage; exit 0 ;;
    *)               die "unknown option: $arg  (try --help)" ;;
  esac
done

# ─── .zshrc block ───────────────────────────────────────────────────────
BACKED_UP=0
backup_zshrc() {
  [ -f "$ZSHRC" ] || return 0
  [ "$BACKED_UP" = 1 ] && return 0
  local dest stamp n=1
  stamp=$(date +%Y%m%d-%H%M%S)
  dest=$ZSHRC.bak-$stamp
  # Never overwrite an older backup made in the same second.
  while [ -e "$dest" ]; do n=$((n + 1)); dest=$ZSHRC.bak-$stamp-$n; done
  run cp -p "$ZSHRC" "$dest"
  note "backup of your .zshrc: $dest"
  BACKED_UP=1
}

has_block() { [ -f "$ZSHRC" ] && grep -qF "$MARK_BEGIN" "$ZSHRC"; }

remove_block() {
  local tmp
  tmp=$(mktemp "${TMPDIR:-/tmp}/zshrc.XXXXXX")
  # Drop the block, and the blank lines it leaves at the end of the file.
  awk -v b="$MARK_BEGIN" -v e="$MARK_END" '
    $0 == b { skip = 1; next }
    $0 == e { skip = 0; next }
    skip    { next }
    /^$/    { blank++; next }
            { while (blank > 0) { print ""; blank-- } print }
  ' "$ZSHRC" > "$tmp"
  cat "$tmp" > "$ZSHRC"
  rm -f "$tmp"
}

# ─── uninstall ──────────────────────────────────────────────────────────
if [ "$UNINSTALL" = 1 ]; then
  step "Removing the zsh layer"
  if has_block; then
    backup_zshrc
    if [ "$DRY" != 1 ]; then remove_block; fi
    report removed remove "the ghostty-zsh block from $ZSHRC"
  else
    note "no ghostty-zsh block found in $ZSHRC"
  fi
  if [ "$PURGE" = 1 ]; then
    for d in "$CFG_DIR" "$DATA_DIR"; do
      case $d in
        */ghostty-zsh) if [ -d "$d" ]; then run rm -rf -- "$d"; report deleted delete "$d"; fi ;;
        *) warn "refusing to delete unexpected path: $d" ;;
      esac
    done
  else
    note "kept $CFG_DIR and $DATA_DIR  (add --purge to delete them too)"
  fi
  printf '\nDone. Open a new tab, or run  exec zsh\n'
  exit 0
fi

# ─── checks ─────────────────────────────────────────────────────────────
[ -r "$SCRIPT_DIR/ghostty.zsh" ]   || die "ghostty.zsh is missing next to install.sh"
[ -r "$SCRIPT_DIR/starship.toml" ] || die "starship.toml is missing next to install.sh"

OS=${GZ_INSTALL_OS:-$(uname -s)}
printf '%sGhostty zsh layer%s  ·  %s%s%s\n' "$B" "$Z" "$D" "$OS" "$Z"
[ "$DRY" = 1 ] && note "dry run: nothing will be changed"

# ─── 1 · helper tools ───────────────────────────────────────────────────
PM=none
SUDO=''
BREW_BIN=''
STARSHIP_NEEDS_SCRIPT=0

detect_pm() {
  if [ -n "${GZ_INSTALL_PM:-}" ]; then PM=$GZ_INSTALL_PM; return; fi
  local b
  for b in /opt/homebrew/bin/brew /usr/local/bin/brew /home/linuxbrew/.linuxbrew/bin/brew; do
    if [ -x "$b" ]; then BREW_BIN=$b; fi
  done
  if have brew; then BREW_BIN=$(command -v brew); fi
  if [ "$OS" = Darwin ]; then
    if [ -n "$BREW_BIN" ]; then PM=brew; fi
    return
  fi
  if   have apt-get; then PM=apt
  elif have dnf;     then PM=dnf
  elif have pacman;  then PM=pacman
  elif have zypper;  then PM=zypper
  elif [ -n "$BREW_BIN" ]; then PM=brew
  fi
}

# Is this tool already usable? (Debian and Ubuntu name bat and fd differently.)
tool_present() {
  case $1 in
    bat)     have bat || have batcat ;;
    fd)      have fd || have fdfind ;;
    ripgrep) have rg ;;
    starship) have starship || [ -x "$HOME/.local/bin/starship" ] ;;
    *)       have "$1" ;;
  esac
}

# Package name of a tool for the detected package manager.
pkg_name() {
  case $PM:$1 in
    apt:fd|dnf:fd) printf 'fd-find' ;;
    *)             printf '%s' "$1" ;;
  esac
}

install_packages() {
  step "Helper tools"
  detect_pm
  if [ "$PM" = none ]; then
    if ! tool_present starship; then STARSHIP_NEEDS_SCRIPT=1; fi
    if [ "$OS" = Darwin ]; then
      warn "Homebrew was not found. Install it from https://brew.sh and run this again,"
      warn "or continue without it:  ./install.sh --no-packages"
    else
      warn "no supported package manager found (apt, dnf, pacman, zypper, brew); skipping"
    fi
    return 0
  fi
  note "package manager: $PM"

  local want='' t
  for t in zsh git fzf eza bat fd ripgrep zoxide starship; do
    if tool_present "$t"; then continue; fi
    # Starship has no apt package; it is handled by its own installer below.
    if [ "$t" = starship ] && [ "$PM" = apt ]; then STARSHIP_NEEDS_SCRIPT=1; continue; fi
    want="$want $t"
  done
  if [ -z "$want" ]; then ok "everything is already installed"; return 0; fi
  note "missing:$want"

  if [ "$PM" != brew ] && [ "$(id -u)" -ne 0 ]; then
    if have sudo; then SUDO=sudo; else warn "sudo not found; install these yourself:$want"; return 0; fi
  fi
  if [ "$PM" = brew ] && [ -z "$BREW_BIN" ]; then BREW_BIN=brew; fi

  if ! ask "Install the missing tools with $PM${SUDO:+ (uses sudo)}?"; then
    note "skipped. Everything still works without them; run again any time."
    return 0
  fi

  local pkg failed=''
  case $PM in
    apt)    run ${SUDO:+"$SUDO"} apt-get update || warn "apt-get update failed; trying anyway" ;;
    pacman) run ${SUDO:+"$SUDO"} pacman -Sy --noconfirm || warn "pacman -Sy failed; trying anyway" ;;
  esac
  for t in $want; do
    pkg=$(pkg_name "$t")
    case $PM in
      apt)    run ${SUDO:+"$SUDO"} apt-get install -y "$pkg" || failed="$failed $t" ;;
      dnf)    run ${SUDO:+"$SUDO"} dnf install -y "$pkg" || failed="$failed $t" ;;
      pacman) run ${SUDO:+"$SUDO"} pacman -S --needed --noconfirm "$pkg" || failed="$failed $t" ;;
      zypper) run ${SUDO:+"$SUDO"} zypper --non-interactive install "$pkg" || failed="$failed $t" ;;
      brew)   run "$BREW_BIN" install "$pkg" || failed="$failed $t" ;;
      *)      warn "unknown package manager: $PM"; return 0 ;;
    esac
  done
  case $failed in *starship*) STARSHIP_NEEDS_SCRIPT=1 ;; esac
  if [ -n "$failed" ]; then
    warn "could not install:$failed  (not in your distribution's repositories, or an error)"
    note "the layer skips whatever is missing, nothing breaks"
  else
    report installed install "the missing tools"
  fi
}

install_starship() {
  tool_present starship && return 0
  step "Starship prompt"
  note "Starship is not packaged for your system. The official installer"
  note "downloads one file into ~/.local/bin (no sudo): https://starship.rs/install.sh"
  if ! ask "Run the official Starship installer?"; then
    note "skipped. The layer falls back to a built-in two-line prompt."
    return 0
  fi
  have curl || { warn "curl not found; skipping"; return 0; }
  run mkdir -p "$HOME/.local/bin"
  if [ "$DRY" = 1 ]; then
    note "[dry-run] curl -fsSL https://starship.rs/install.sh | sh -s -- --yes --bin-dir $HOME/.local/bin"
  else
    # Its own closing instructions would only confuse: the layer already does the setup.
    if out=$(curl -fsSL https://starship.rs/install.sh | sh -s -- --yes --bin-dir "$HOME/.local/bin" 2>&1); then
      ok "starship installed to ~/.local/bin"
    else
      warn "the Starship installer failed; continuing without it. Its last lines:"
      printf '%s\n' "$out" | tail -n 6 | sed 's/^/    /'
    fi
  fi
}

if [ "$DO_PKGS" = 1 ]; then
  install_packages
  # Where no package exists (apt, or a failed install), offer the official installer.
  if [ "$DO_STARSHIP" = 1 ] && [ "$STARSHIP_NEEDS_SCRIPT" = 1 ]; then install_starship; fi
fi

# ─── 2 · plugins ────────────────────────────────────────────────────────
clone_or_update() {
  local url=$1 dir=$2
  if [ -d "$dir/.git" ]; then
    if run git -C "$dir" pull --ff-only --quiet; then report updated update "$(basename "$dir")"; else warn "could not update $(basename "$dir")"; fi
  else
    if run git clone --depth 1 --quiet "$url" "$dir"; then report downloaded download "$(basename "$dir")"; else warn "could not download $url"; fi
  fi
}

if [ "$DO_PLUGINS" = 1 ]; then
  step "Plugins"
  if ! have git; then
    warn "git is not installed, so the plugins cannot be downloaded. Install git and run again."
  else
    run mkdir -p "$PLUG_DIR"
    clone_or_update https://github.com/zsh-users/zsh-autosuggestions.git         "$PLUG_DIR/zsh-autosuggestions"
    clone_or_update https://github.com/zsh-users/zsh-syntax-highlighting.git     "$PLUG_DIR/zsh-syntax-highlighting"
    clone_or_update https://github.com/zsh-users/zsh-completions.git             "$PLUG_DIR/zsh-completions"
    clone_or_update https://github.com/zsh-users/zsh-history-substring-search.git "$PLUG_DIR/zsh-history-substring-search"
    clone_or_update https://github.com/Aloxaf/fzf-tab.git                         "$PLUG_DIR/fzf-tab"
  fi
fi

# ─── 3 · config files ───────────────────────────────────────────────────
step "Config files"
run mkdir -p "$CFG_DIR"
for f in ghostty.zsh starship.toml; do
  if [ -f "$CFG_DIR/$f" ] && ! cmp -s "$SCRIPT_DIR/$f" "$CFG_DIR/$f"; then
    run cp -p "$CFG_DIR/$f" "$CFG_DIR/$f.bak-$(date +%Y%m%d-%H%M%S)"
    note "your previous $f was kept as $f.bak-..."
  fi
  run cp "$SCRIPT_DIR/$f" "$CFG_DIR/$f"
  report installed install "$CFG_DIR/$f"
done

# ─── 4 · ~/.zshrc ───────────────────────────────────────────────────────
# shellcheck disable=SC2088  # a label, not a path
step "~/.zshrc"
if has_block; then
  ok "already set up in $ZSHRC"
else
  if [ -f "$ZSHRC" ] && grep -qE 'oh-my-zsh|powerlevel10k|p10k|zinit|antigen|zplug|prezto|spaceship|starship init|zsh-autosuggestions|zsh-syntax-highlighting' "$ZSHRC"; then
    warn "your .zshrc already uses a plugin manager, prompt or one of these plugins."
    note "The layer coexists with them and keeps a custom prompt. If you see doubled"
    note "suggestions or colors, remove the duplicate from your own setup."
  fi
  backup_zshrc
  if [ "$DRY" = 1 ]; then
    report added add "the ghostty-zsh block to $ZSHRC"
  else
    {
      printf '\n%s\n' "$MARK_BEGIN"
      printf '%s\n' '# Added by the Ghostty config pack. Keep this block last in the file.'
      printf '%s\n' '# Undo it with:  install.sh --uninstall   (or just delete these lines).'
      # shellcheck disable=SC2016  # the $HOME text must stay unexpanded in .zshrc
      printf '%s\n' '[[ -r "${XDG_CONFIG_HOME:-$HOME/.config}/ghostty-zsh/ghostty.zsh" ]] && source "${XDG_CONFIG_HOME:-$HOME/.config}/ghostty-zsh/ghostty.zsh"'
      printf '%s\n' "$MARK_END"
    } >> "$ZSHRC"
    report added add "the ghostty-zsh block to $ZSHRC"
  fi
fi

# ─── check ──────────────────────────────────────────────────────────────
step "Check"
if [ "$DRY" = 1 ]; then
  note "skipped in dry-run mode"
elif have zsh; then
  if out=$(zsh -ic 'print -r -- "loaded:  ${_gz_on[*]}"; print -r -- "missing: ${_gz_off[*]:-nothing}"' </dev/null 2>&1); then
    printf '%s\n' "$out" | tail -n 2 | sed 's/^/  /'
  else
    warn "zsh reported a problem while loading your .zshrc:"
    printf '%s\n' "$out" | tail -n 5 | sed 's/^/    /'
  fi
else
  warn "zsh is not installed yet; install it and run this script again"
fi

login_shell=$(basename "${SHELL:-}")
if [ "$login_shell" != zsh ] && [ "$OS" != Darwin ]; then
  printf '\n'
  warn "Your login shell is ${login_shell:-unknown}, so Ghostty will keep opening that."
  note "Switch with:  chsh -s \"\$(command -v zsh)\"   then log out and in."
  note "Or, to try zsh in Ghostty only, add this line to its config:  command = zsh"
fi

printf '\n%sDone.%s Open a new Ghostty tab (or run %sexec zsh%s), then try %sgzhelp%s.\n' "$B" "$Z" "$B" "$Z" "$B" "$Z"
