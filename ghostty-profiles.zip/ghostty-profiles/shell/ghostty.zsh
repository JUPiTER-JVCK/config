# ╔══════════════════════════════════════════════════════════════════════╗
# ║  ghostty.zsh  ·  the zsh layer for the five Ghostty profiles         ║
# ║  autosuggest · syntax colors · fuzzy Tab menu · fzf · zoxide · prompt ║
# ╚══════════════════════════════════════════════════════════════════════╝
#
# Ghostty has no plugin system, so autocomplete, autosuggestions and syntax
# colors come from the shell. This file adds them to zsh. It is loaded by one
# line in ~/.zshrc (shell/install.sh adds that line for you).
#
# Safe on a bare machine: every plugin and tool is optional and is skipped
# when missing, so nothing prints an error. Run  gzhelp  to see what loaded.
#
# Colors: each Ghostty profile exports GHOSTTY_PROFILE. Section 2 turns that
# into the grey of ghost text and comments, the fzf accent, and so on. In
# other terminals the colors of the terminal's own palette are used.
#
# Switches (set them in ~/.zshrc above the line that loads this file):
#   GZ_VI_MODE=1       vi keys on the command line instead of emacs keys
#   GZ_PROMPT=ghostty  always use this prompt   (default: only replace zsh's
#                      stock prompt;  GZ_PROMPT=keep never touches the prompt)
#   GZ_NO_ALIASES=1    skip the ls / git / navigation aliases
#
# Contents
#   1 Setup          2 Colors          3 Shell options     4 Tools
#   5 Completion     6 fzf + plugins   7 Prompt            8 Aliases & helpers
#   9 More plugins   10 Key bindings   11 Help (gzhelp)

# ─── 1 · SETUP ───────────────────────────────────────────────────────────
# Only for a shell you type into (stdin is a terminal). When an editor or script runs
# zsh -ic 'cmd' there is nothing to configure, and old fzf files print warnings.
[[ -n ${ZSH_VERSION-} && -o interactive && -t 0 && ${TERM-} != dumb ]] || return 0
[[ -n ${_GZ_LOADED-} ]] && return 0
typeset -g _GZ_LOADED=1

autoload -Uz is-at-least
if ! is-at-least 5.3; then
  print -u2 -- "ghostty.zsh: needs zsh 5.3 or newer (this is $ZSH_VERSION), skipping."
  return 0
fi

typeset -g _gz_dir=${${(%):-%x}:A:h}
typeset -g _gz_plug=${GHOSTTY_ZSH_PLUGINS:-${XDG_DATA_HOME:-$HOME/.local/share}/ghostty-zsh/plugins}
typeset -g _gz_cache=${XDG_CACHE_HOME:-$HOME/.cache}/ghostty-zsh
typeset -ga _gz_on=() _gz_off=()          # what loaded / what is missing (shown by gzhelp)
[[ -d $_gz_cache ]] || mkdir -p -- "$_gz_cache" 2>/dev/null

# Find a plugin file. Looks in our own folder first, then where Homebrew and
# Linux distributions put the same plugins. The result is left in $REPLY.
_gz_find() {
  emulate -L zsh
  local d
  REPLY=
  for d in "$_gz_plug" /opt/homebrew/share /usr/local/share /home/linuxbrew/.linuxbrew/share \
           /usr/share /usr/share/zsh/plugins; do
    if [[ -r $d/$1/$2 ]]; then REPLY=$d/$1/$2; return 0; fi
  done
  return 1
}

# ─── 2 · COLORS ──────────────────────────────────────────────────────────
# dim = ghost text and comments, sel = selected row, acc = accent, bg = page.
# Every grey keeps at least 4:1 contrast against its profile's background.
case ${GHOSTTY_PROFILE-} in
  catppuccin) _gz_bg='#1e1e2e' _gz_dim='#7f849c' _gz_sel='#353749' _gz_acc='#89b4fa' ;;
  tokyonight) _gz_bg='#1a1b26' _gz_dim='#737aa2' _gz_sel='#283457' _gz_acc='#7aa2f7' ;;
  gruvbox)    _gz_bg='#282828' _gz_dim='#928374' _gz_sel='#665c54' _gz_acc='#fabd2f' ;;
  cyberdeck)  _gz_bg='#0a0e1a' _gz_dim='#6a7a9e' _gz_sel='#1d2b52' _gz_acc='#25f4ee' ;;
  rosepine)   _gz_bg='#191724' _gz_dim='#7e7a95' _gz_sel='#403d52' _gz_acc='#c4a7e7' ;;
  *)          _gz_bg=0         _gz_dim=8         _gz_sel=-1        _gz_acc=4 ;;
esac

# fzf colors. Hex values are used only inside a known Ghostty profile; the
# fallback uses ANSI numbers, so it follows whatever palette the terminal has.
if [[ $_gz_dim == \#* ]]; then
  typeset -g _gz_fzf_colors="--color=fg:-1,bg:-1,hl:$_gz_acc,fg+:15,bg+:$_gz_sel,hl+:$_gz_acc,info:$_gz_dim,prompt:$_gz_acc,pointer:$_gz_acc,marker:$_gz_acc,spinner:$_gz_dim,header:$_gz_dim,border:$_gz_dim,gutter:-1"
else
  typeset -g _gz_fzf_colors="--color=fg:-1,bg:-1,hl:4,fg+:15,bg+:-1,hl+:12,info:8,prompt:5,pointer:1,marker:2,spinner:3,header:8,border:8,gutter:-1"
fi

# ─── 3 · SHELL OPTIONS ───────────────────────────────────────────────────
setopt AUTO_CD AUTO_PUSHD PUSHD_IGNORE_DUPS PUSHD_SILENT   # type a folder name to enter it
setopt INTERACTIVE_COMMENTS                                # allow  # comments  at the prompt
setopt NO_BEEP NO_FLOW_CONTROL                             # no beeps; Ctrl+S no longer freezes
setopt COMPLETE_IN_WORD ALWAYS_TO_END LONG_LIST_JOBS

# History: big, shared between tabs, no duplicates, a leading space = private.
: ${HISTFILE:=${ZDOTDIR:-$HOME}/.zsh_history}
(( ${HISTSIZE:-0} >= 50000 )) || HISTSIZE=50000
(( ${SAVEHIST:-0} >= 50000 )) || SAVEHIST=50000
setopt EXTENDED_HISTORY SHARE_HISTORY HIST_IGNORE_ALL_DUPS HIST_FIND_NO_DUPS
setopt HIST_IGNORE_SPACE HIST_REDUCE_BLANKS HIST_VERIFY

# File colors for ls and for the completion menu (only if the system has none).
if [[ -z ${LS_COLORS-} ]]; then
  if (( $+commands[dircolors] )); then
    eval "$(dircolors -b 2>/dev/null)"
  elif (( $+commands[gdircolors] )); then
    eval "$(gdircolors -b 2>/dev/null)"
  else
    export LS_COLORS='di=1;34:ln=36:so=35:pi=33:ex=1;32:bd=34;46:cd=34;43:su=30;41:sg=30;46'
  fi
  # Folders that anyone can write to are blue-on-green by default; tone down.
  export LS_COLORS="${LS_COLORS}:ow=1;34:tw=1;34"
fi

# Colored man pages. These are ANSI names, so they follow each profile.
export LESS_TERMCAP_md=${LESS_TERMCAP_md-$'\e[1;36m'}   # headings and bold: cyan
export LESS_TERMCAP_us=${LESS_TERMCAP_us-$'\e[4;32m'}   # underlined words: green
export LESS_TERMCAP_so=${LESS_TERMCAP_so-$'\e[30;43m'}  # status bar, search hits
export LESS_TERMCAP_ue=${LESS_TERMCAP_ue-$'\e[0m'}
export LESS_TERMCAP_se=${LESS_TERMCAP_se-$'\e[0m'}
export LESS_TERMCAP_me=${LESS_TERMCAP_me-$'\e[0m'}

# ─── 4 · TOOLS ───────────────────────────────────────────────────────────
# User-level installs (Starship's installer, pipx, ...) land in ~/.local/bin.
typeset -U path
[[ -d $HOME/.local/bin ]] && path+=("$HOME/.local/bin")

# Debian and Ubuntu install fd and bat under other names.
typeset -g _gz_fd= _gz_bat=
if (( $+commands[fd] )); then _gz_fd=fd; elif (( $+commands[fdfind] )); then _gz_fd=fdfind; fi
if (( $+commands[bat] )); then _gz_bat=bat; elif (( $+commands[batcat] )); then _gz_bat=batcat; fi
[[ $_gz_fd == fdfind ]] && alias fd=fdfind
[[ $_gz_bat == batcat ]] && alias bat=batcat
[[ -n $_gz_bat ]] && export BAT_THEME=${BAT_THEME:-ansi}   # ANSI theme: follows the profile

typeset -g _gz_use_ftb=0
if (( $+commands[fzf] )) && is-at-least 5.8 && _gz_find fzf-tab fzf-tab.plugin.zsh; then
  _gz_use_ftb=1
fi

for _gz_t in fzf eza zoxide starship; do
  (( $+commands[$_gz_t] )) || _gz_off+=($_gz_t)
done
[[ -n $_gz_bat ]] || _gz_off+=(bat)
[[ -n $_gz_fd ]]  || _gz_off+=(fd)

# fzf options. Anything you already export is kept and wins over ours.
if (( $+commands[fzf] )); then
  if [[ -z ${_GZ_FZF_OPTS-} ]]; then
    export _GZ_FZF_OPTS="--height=60% --layout=reverse --border=rounded --info=inline --cycle $_gz_fzf_colors"
    export FZF_DEFAULT_OPTS="$_GZ_FZF_OPTS${FZF_DEFAULT_OPTS:+ $FZF_DEFAULT_OPTS}"
  fi
  if [[ -n $_gz_bat ]]; then
    _gz_pf="$_gz_bat --style=numbers --color=always --line-range=:300 {}"
  else
    _gz_pf='head -n 300 {}'
  fi
  if (( $+commands[eza] )); then
    _gz_pd='eza --tree --level=2 --color=always --icons=always {}'
  else
    _gz_pd='ls -la {}'
  fi
  export FZF_CTRL_T_OPTS=${FZF_CTRL_T_OPTS-"--preview 'if [ -d {} ]; then $_gz_pd; else $_gz_pf; fi' --preview-window=right:55% --bind=ctrl-/:toggle-preview"}
  export FZF_ALT_C_OPTS=${FZF_ALT_C_OPTS-"--preview '$_gz_pd' --preview-window=right:55% --bind=ctrl-/:toggle-preview"}
  if [[ -n $_gz_fd ]]; then
    export FZF_DEFAULT_COMMAND=${FZF_DEFAULT_COMMAND-"$_gz_fd --type f --hidden --follow --exclude .git"}
    export FZF_CTRL_T_COMMAND=${FZF_CTRL_T_COMMAND-"$_gz_fd --hidden --follow --exclude .git"}
    export FZF_ALT_C_COMMAND=${FZF_ALT_C_COMMAND-"$_gz_fd --type d --hidden --follow --exclude .git"}
    # Used by the  **<Tab>  trigger.
    _fzf_compgen_path() { command $_gz_fd --hidden --follow --exclude .git . "$1" }
    _fzf_compgen_dir()  { command $_gz_fd --type d --hidden --follow --exclude .git . "$1" }
  elif (( $+commands[rg] )); then
    export FZF_DEFAULT_COMMAND=${FZF_DEFAULT_COMMAND-"rg --files --hidden --follow --glob '!.git'"}
  fi
fi

# ─── 5 · COMPLETION ──────────────────────────────────────────────────────
typeset -U fpath
for _gz_d in "$_gz_plug/zsh-completions/src" /opt/homebrew/share/zsh-completions \
             /usr/local/share/zsh-completions /usr/share/zsh-completions \
             /opt/homebrew/share/zsh/site-functions /usr/local/share/zsh/site-functions \
             /home/linuxbrew/.linuxbrew/share/zsh/site-functions; do
  [[ -d $_gz_d ]] && fpath+=("$_gz_d")
done
[[ -d $_gz_plug/zsh-completions/src || -d /opt/homebrew/share/zsh-completions \
   || -d /usr/local/share/zsh-completions || -d /usr/share/zsh-completions ]] \
  && _gz_on+=(zsh-completions) || _gz_off+=(zsh-completions)

# Build the completion index once, then reuse it for a day (fast start-up).
_gz_compinit() {
  emulate -L zsh
  setopt extendedglob
  local dump=$_gz_cache/zcompdump-$ZSH_VERSION
  autoload -Uz compinit
  if [[ -n $dump(#qN.mh-20) ]]; then
    compinit -C -i -d "$dump"
  else
    compinit -i -d "$dump"
    { [[ -s $dump ]] && zcompile "$dump" } &!   # speeds up the next start
  fi
}
(( $+functions[compdef] )) || _gz_compinit

zstyle ':completion:*' matcher-list 'm:{a-zA-Z}={A-Za-z}' 'r:|[._-]=* r:|=*' 'l:|=* r:|=*'
zstyle ':completion:*' use-cache yes
zstyle ':completion:*' cache-path "$_gz_cache/zcompcache"
zstyle ':completion:*' list-colors ${(s.:.)LS_COLORS}
zstyle ':completion:*' special-dirs true
zstyle ':completion:*' squeeze-slashes true
zstyle ':completion:*' group-name ''
zstyle ':completion:*:descriptions' format '[%d]'
zstyle ':completion:*:messages' format ' %F{3}%d%f'
zstyle ':completion:*:warnings' format ' %F{1}nothing matched%f'
zstyle ':completion:*:*:*:*:processes' command 'ps -u $USER -o pid,user,comm -w -w'
if (( _gz_use_ftb )); then
  zstyle ':completion:*' menu no        # fzf-tab draws the menu instead
else
  zstyle ':completion:*' menu select    # arrow-key menu when fzf is missing
fi

# ─── 6 · FZF AND THE FIRST PLUGINS (order matters) ───────────────────────
# a) fzf: Ctrl+T (files), Ctrl+R (history), Alt+C (folders), and  **<Tab>.
#    Newer fzf prints its zsh script; older packages ship it as files.
if (( $+commands[fzf] )); then
  _gz_fzfzsh=$(fzf --zsh 2>/dev/null)
  if [[ -n $_gz_fzfzsh ]]; then
    eval "$_gz_fzfzsh"
  else
    for _gz_d in /usr/share/doc/fzf/examples /usr/share/fzf /usr/share/fzf/shell \
                 /opt/homebrew/opt/fzf/shell /usr/local/opt/fzf/shell \
                 /home/linuxbrew/.linuxbrew/opt/fzf/shell "$HOME/.fzf/shell" \
                 /usr/local/share/examples/fzf/shell; do
      if [[ -r $_gz_d/key-bindings.zsh ]]; then
        source "$_gz_d/key-bindings.zsh"
        [[ -r $_gz_d/completion.zsh ]] && source "$_gz_d/completion.zsh"
        break
      fi
    done
  fi
  unset _gz_fzfzsh
  _gz_on+=(fzf)
fi

# b) zoxide: "z foo" jumps to the folder you use most that matches "foo".
if (( $+commands[zoxide] )); then
  eval "$(zoxide init zsh)"
  _gz_on+=(zoxide)
fi

# c) fzf-tab: the Tab menu becomes an fzf list with previews. It has to load
#    after compinit and after fzf's own bindings, but before the plugins that
#    wrap widgets (the next two).
if (( _gz_use_ftb )); then
  _gz_find fzf-tab fzf-tab.plugin.zsh && source "$REPLY"
  zstyle ':fzf-tab:*' fzf-flags ${_gz_fzf_colors}
  # Preview: folder contents or file text for anything that is a path.
  if (( $+commands[eza] )); then _gz_ftb_d='eza --tree --level=2 --color=always --icons=always'; else _gz_ftb_d='ls -la'; fi
  if [[ -n $_gz_bat ]]; then _gz_ftb_f="$_gz_bat --color=always --style=numbers --line-range=:200"; else _gz_ftb_f='head -n 200'; fi
  zstyle ':fzf-tab:complete:*:*' fzf-preview \
    "if [ -d \"\${(Q)realpath}\" ]; then $_gz_ftb_d \"\${(Q)realpath}\"; elif [ -f \"\${(Q)realpath}\" ]; then $_gz_ftb_f \"\${(Q)realpath}\"; fi"
  zstyle ':fzf-tab:complete:(-command-|-parameter-|-brace-parameter-|export|unset|expand):*' \
    fzf-preview 'echo ${(P)word}'
  zstyle ':fzf-tab:complete:git-(checkout|switch|branch|merge|rebase|log):*' \
    fzf-preview 'git log --oneline --graph --decorate --color=always -n 20 $word 2>/dev/null'
  _gz_on+=(fzf-tab)
else
  _gz_off+=(fzf-tab)
fi

# d) Autosuggestions: grey "ghost" text from your history while you type.
if _gz_find zsh-autosuggestions zsh-autosuggestions.zsh; then
  ZSH_AUTOSUGGEST_STRATEGY=(history)
  ZSH_AUTOSUGGEST_HIGHLIGHT_STYLE="fg=$_gz_dim"
  ZSH_AUTOSUGGEST_BUFFER_MAX_SIZE=200
  source "$REPLY"
  _gz_on+=(autosuggestions)
else
  _gz_off+=(autosuggestions)
fi

# ─── 7 · PROMPT ──────────────────────────────────────────────────────────
# By default only zsh's stock prompt is replaced, so Powerlevel10k,
# Oh My Zsh themes or your own prompt are left alone.
_gz_prompt=0
case ${GZ_PROMPT-auto} in
  ghostty) _gz_prompt=1 ;;
  keep)    _gz_prompt=0 ;;
  *)       case ${PROMPT-} in
             ''|'%m%# '|'%# '|'%n@%m %1~ %# '|'%n@%m %~ %# '|'[%n@%m %1~]%# '|'[%n@%m %~]%# ') _gz_prompt=1 ;;
           esac ;;
esac
if (( _gz_prompt )); then
  if (( $+commands[starship] )); then
    if [[ -z ${STARSHIP_CONFIG-} && ! -e ${XDG_CONFIG_HOME:-$HOME/.config}/starship.toml && -r $_gz_dir/starship.toml ]]; then
      export STARSHIP_CONFIG=$_gz_dir/starship.toml
    fi
    eval "$(starship init zsh)"
    _gz_on+=(starship)
  else
    # No starship installed: a small prompt with the folder, git branch and a
    # status-colored arrow. The branch symbol comes from Ghostty's built-in
    # Nerd Font fallback.
    autoload -Uz vcs_info add-zsh-hook
    zstyle ':vcs_info:*' enable git
    zstyle ':vcs_info:git:*' formats ' %F{5} %b%f'
    zstyle ':vcs_info:git:*' actionformats ' %F{5} %b%f %F{3}(%a)%f'
    add-zsh-hook precmd vcs_info
    setopt PROMPT_SUBST
    PROMPT=$'\n%F{4}%B%~%b%f${vcs_info_msg_0_}\n%(?.%F{2}.%F{1})❯%f '
    _gz_on+=(prompt)
  fi
fi

# ─── 8 · ALIASES & HELPERS ───────────────────────────────────────────────
mkcd() { mkdir -p -- "$1" && cd -- "$1" }

up() {
  emulate -L zsh
  local n=${1:-1} d=
  [[ $n == <-> ]] || { print -u2 -- "usage: up [levels]"; return 2 }
  repeat $n d+=../
  cd -- "$d"
}

extract() {
  emulate -L zsh
  local f
  (( $# )) || { print -u2 -- "usage: extract <archive> ..."; return 2 }
  for f in "$@"; do
    [[ -f $f ]] || { print -u2 -- "extract: no such file: $f"; continue }
    case ${f:l} in
      *.tar.gz|*.tgz)   tar -xzf "$f" ;;
      *.tar.bz2|*.tbz2) tar -xjf "$f" ;;
      *.tar.xz|*.txz)   tar -xJf "$f" ;;
      *.tar.zst)        tar --zstd -xf "$f" ;;
      *.tar)            tar -xf "$f" ;;
      *.zip|*.jar)      unzip "$f" ;;
      *.gz)             gunzip -k -- "$f" ;;
      *.bz2)            bunzip2 -k -- "$f" ;;
      *.xz)             unxz -k -- "$f" ;;
      *.7z)             7z x "$f" ;;
      *.rar)            unrar x "$f" ;;
      *)                print -u2 -- "extract: don't know how to unpack: $f"; return 1 ;;
    esac
  done
}

if [[ -z ${GZ_NO_ALIASES-} ]]; then
  if (( $+commands[eza] )); then
    alias ls='eza --icons=auto --group-directories-first'
    alias ll='eza -l --icons=auto --group-directories-first --git'
    alias la='eza -la --icons=auto --group-directories-first --git'
    alias lt='eza --tree --level=2 --icons=auto --group-directories-first'
  else
    if ls --color=auto / >/dev/null 2>&1; then alias ls='ls --color=auto'; else alias ls='ls -G'; fi
    alias ll='ls -lh'
    alias la='ls -lAh'
  fi
  alias grep='grep --color=auto'
  alias ...='cd ../..'
  alias ....='cd ../../..'
  alias reload='exec zsh'
  alias path='print -rl -- $path'
  alias g='git'
  alias gst='git status -sb'
  alias gd='git diff'
  alias gds='git diff --staged'
  alias ga='git add'
  alias gc='git commit'
  alias gp='git push'
  alias glg='git log --oneline --graph --decorate -20'
fi

# ─── 9 · MORE PLUGINS (these two must come last) ─────────────────────────
# Widgets of our own have to exist before the highlighter wraps them.
_gz_sudo_toggle() {
  local pos
  if [[ -z $BUFFER ]]; then          # empty line: start from the last command
    BUFFER=${history[$((HISTCMD - 1))]}
    CURSOR=${#BUFFER}
  fi
  pos=$CURSOR
  if [[ $BUFFER == sudo\ * ]]; then
    BUFFER=${BUFFER#sudo }
    CURSOR=$(( pos > 5 ? pos - 5 : 0 ))
  else
    BUFFER="sudo $BUFFER"
    CURSOR=$(( pos + 5 ))
  fi
}
_gz_fancy_ctrl_z() {
  if [[ -z $BUFFER ]]; then
    BUFFER=fg
    zle accept-line
  else
    zle push-input
    zle clear-screen
  fi
}
autoload -Uz edit-command-line up-line-or-beginning-search down-line-or-beginning-search
zle -N _gz_sudo_toggle
zle -N _gz_fancy_ctrl_z
zle -N edit-command-line
zle -N up-line-or-beginning-search
zle -N down-line-or-beginning-search

# a) Syntax highlighting: valid commands green, typos red, quotes and paths
#    colored while you type.
if _gz_find zsh-syntax-highlighting zsh-syntax-highlighting.zsh; then
  ZSH_HIGHLIGHT_HIGHLIGHTERS=(main brackets pattern)
  ZSH_HIGHLIGHT_MAXLENGTH=300
  source "$REPLY"
  # The default comment color is "black", which disappears on dark themes.
  ZSH_HIGHLIGHT_STYLES[comment]="fg=$_gz_dim"
  # Make a destructive command impossible to miss.
  ZSH_HIGHLIGHT_PATTERNS+=('rm -rf *' 'fg=15,bold,bg=1' 'rm -fr *' 'fg=15,bold,bg=1')
  _gz_on+=(syntax-highlighting)
else
  _gz_off+=(syntax-highlighting)
fi

# b) History search on Up/Down: type "git c", press Up, get the last command
#    containing it. Has to load after the highlighter.
if _gz_find zsh-history-substring-search zsh-history-substring-search.zsh; then
  HISTORY_SUBSTRING_SEARCH_ENSURE_UNIQUE=1
  HISTORY_SUBSTRING_SEARCH_HIGHLIGHT_FOUND="bg=$_gz_acc,fg=$_gz_bg,bold"
  HISTORY_SUBSTRING_SEARCH_HIGHLIGHT_NOT_FOUND="bg=1,fg=$_gz_bg,bold"
  source "$REPLY"
  _gz_on+=(history-search)
else
  _gz_off+=(history-search)
fi

# ─── 10 · KEY BINDINGS ───────────────────────────────────────────────────
zmodload zsh/terminfo 2>/dev/null
if [[ -n ${GZ_VI_MODE-} ]]; then
  bindkey -v
  KEYTIMEOUT=10
else
  bindkey -e
fi

() {
  emulate -L zsh
  local km k up=up-line-or-beginning-search down=down-line-or-beginning-search
  if (( $+widgets[history-substring-search-up] )); then
    up=history-substring-search-up down=history-substring-search-down
  fi
  for km in emacs viins; do
    for k in '^[[A' '^[OA' ${terminfo[kcuu1]-}; do bindkey -M $km $k $up; done
    for k in '^[[B' '^[OB' ${terminfo[kcud1]-}; do bindkey -M $km $k $down; done
    # Home, End and Delete
    for k in '^[[H' '^[OH' '^[[1~' ${terminfo[khome]-}; do bindkey -M $km $k beginning-of-line; done
    for k in '^[[F' '^[OF' '^[[4~' ${terminfo[kend]-};  do bindkey -M $km $k end-of-line; done
    bindkey -M $km '^[[3~'   delete-char
    bindkey -M $km '^[[3;5~' kill-word
    # Ctrl+arrows and Alt+arrows jump by word, and also take one word of a
    # grey suggestion. (On macOS, Option+arrows already send Esc b / Esc f.)
    bindkey -M $km '^[[1;5C' forward-word
    bindkey -M $km '^[[1;5D' backward-word
    bindkey -M $km '^[[1;3C' forward-word
    bindkey -M $km '^[[1;3D' backward-word
    # Extras
    bindkey -M $km '^[^['  _gz_sudo_toggle       # Esc Esc: add or remove sudo
    bindkey -M $km '^X^E'  edit-command-line     # edit the line in $EDITOR
    bindkey -M $km '^Z'    _gz_fancy_ctrl_z      # Ctrl+Z on an empty line: fg
    (( $+widgets[autosuggest-accept] ))  && bindkey -M $km '^ '   autosuggest-accept    # Ctrl+Space
    (( $+widgets[autosuggest-execute] )) && bindkey -M $km '^[^M' autosuggest-execute   # Alt+Enter
  done
  if [[ -n ${GZ_VI_MODE-} ]]; then
    bindkey -M vicmd 'k' $up
    bindkey -M vicmd 'j' $down
  fi
}

# ─── 11 · HELP ───────────────────────────────────────────────────────────
gzhelp() {
  emulate -L zsh
  unsetopt prompt_subst        # emulate leaves this one alone; keeps $EDITOR literal below
  local h='%B%F{6}' r='%f%b' d="%F{$_gz_dim}"
  print -P -- "${h}Ghostty zsh layer${r}   ${d}profile: ${GHOSTTY_PROFILE:-none}%f"
  print -P -- ""
  print -P -- "${h}Typing${r}"
  print -P -- "  %B→%b or %BEnd%b           accept the grey suggestion"
  print -P -- "  %BCtrl+→%b / %BAlt+→%b     accept one word of it"
  print -P -- "  %BCtrl+Space%b          accept it       %BAlt+Enter%b   accept and run"
  print -P -- "  %B↑%b / %B↓%b              history that contains what you typed"
  print -P -- "  %BEsc Esc%b             add or remove sudo"
  print -P -- "  %BCtrl+X Ctrl+E%b       edit the line in \$EDITOR"
  print -P -- "  %BCtrl+Z%b              on an empty line: bring back the stopped job"
  print -P -- ""
  print -P -- "${h}Tab menu${r}  (fzf-tab)"
  print -P -- "  %BTab%b / %BShift+Tab%b    move down / up      %BEnter%b   accept"
  print -P -- "  %BF1%b / %BF2%b            switch between groups   %B/%b   go deeper in a path"
  print -P -- ""
  print -P -- "${h}Find things${r}  (fzf, zoxide)"
  print -P -- "  %BCtrl+R%b history      %BCtrl+T%b files      %BAlt+C%b jump to a folder"
  print -P -- "  %Bz name%b              jump to a folder you use often    %Bzi%b  pick from a list"
  print -P -- "  %BCtrl+/%b              show or hide the preview (Ctrl+T and Alt+C lists)"
  print -P -- ""
  print -P -- "${h}Commands${r}"
  print -P -- "  ls ll la lt            eza listings        mkcd dir       make a folder and enter it"
  print -P -- "  up 3                   go up 3 folders     extract file   unpack any archive"
  print -P -- "  gst gd ga gc gp glg    short git           reload         restart the shell"
  print -P -- ""
  print -P -- "${h}Status${r}"
  print -P -- "  loaded   ${_gz_on[*]:-none}"
  if (( $#_gz_off )); then
    print -P -- "  missing  ${d}${_gz_off[*]}%f   (run install.sh again to add what can be added)"
  fi
}

# ─── CLEAN UP ────────────────────────────────────────────────────────────
unset _gz_d _gz_t _gz_pf _gz_pd _gz_ftb_d _gz_ftb_f _gz_prompt
