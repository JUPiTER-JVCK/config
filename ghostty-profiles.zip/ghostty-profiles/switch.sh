#!/usr/bin/env bash
# ╔══════════════════════════════════════════════════════════════════════╗
# ║  switch.sh  ·  put one of the five Ghostty profiles in place         ║
# ╚══════════════════════════════════════════════════════════════════════╝
#
# Copies a profile from ./configs to the place Ghostty reads its settings
# from, after backing up what is there. You can also just paste a profile
# into Ghostty's config file by hand; this saves the hunting for the path.
#
#   ./switch.sh              pick from a menu
#   ./switch.sh 3            by number          ./switch.sh glass   by name
#   ./switch.sh --list       show the profiles
#   ./switch.sh --path       print where the config file lives
#   ./switch.sh --restore    put the newest backup back
#   ./switch.sh --help       all options
#
# Works on macOS and Linux with the stock tools only.

set -euo pipefail

HERE=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)
CONF_DIR=$HERE/configs
OS=${GZ_SWITCH_OS:-$(uname -s)}
XDG=${XDG_CONFIG_HOME:-$HOME/.config}

if [ "$OS" = Darwin ]; then
  TARGET_DIR="$HOME/Library/Application Support/com.mitchellh.ghostty"
  RELOAD='Cmd+Shift+,'
else
  TARGET_DIR="$XDG/ghostty"
  RELOAD='Ctrl+Shift+,'
fi
TARGET="$TARGET_DIR/config.ghostty"

# Every other file Ghostty 1.3 reads. They all load, one after the other,
# so a second file can quietly override or double up the profile.
OTHERS=()
add_other() {
  local p=$1 q
  [ "$p" = "$TARGET" ] && return 0
  for q in ${OTHERS[@]+"${OTHERS[@]}"}; do
    [ "$q" = "$p" ] && return 0
  done
  OTHERS+=("$p")
}
add_other "$TARGET_DIR/config"
add_other "$XDG/ghostty/config.ghostty"
add_other "$XDG/ghostty/config"

DRY=0
MOVE_ASIDE=0
MODE=pick
WANT=''

if [ -t 1 ] && [ -z "${NO_COLOR:-}" ]; then
  B=$'\033[1m'; D=$'\033[2m'; R=$'\033[31m'; G=$'\033[32m'; Y=$'\033[33m'; C=$'\033[36m'; Z=$'\033[0m'
else
  B=''; D=''; R=''; G=''; Y=''; C=''; Z=''
fi
ok()   { printf '  %s✔%s %s\n' "$G" "$Z" "$1"; }
note() { printf '  %s%s%s\n' "$D" "$1" "$Z"; }
warn() { printf '  %s!%s %s\n' "$Y" "$Z" "$1" >&2; }
die()  { printf '%sError:%s %s\n' "$R" "$Z" "$1" >&2; exit 1; }
run()  {
  if [ "$DRY" = 1 ]; then printf '  %s[dry-run]%s' "$D" "$Z"; printf ' %q' "$@"; printf '\n'; return 0; fi
  "$@"
}
# Past tense when done, "would ..." in a dry run:  report wrote write thing
report() {
  if [ "$DRY" = 1 ]; then note "would $2 $3"; else ok "$1 $3"; fi
}

usage() {
  cat <<'EOT'
Usage: switch.sh [profile] [options]

  profile          1-5, or a name: daily-driver, glass, workhorse, cyberdeck, zen
  (no profile)     show a menu

  --list           show the profiles and exit
  --path           print where Ghostty's config file lives and exit
  --restore        put the newest backup back
  --move-aside     rename other config files Ghostty would also load, so only
                   the profile is active (they are renamed, never deleted)
  -n, --dry-run    show what would happen, change nothing
  -h, --help       this text
EOT
}

# ─── arguments ──────────────────────────────────────────────────────────
for arg in "$@"; do
  case $arg in
    --list)        MODE=list ;;
    --path)        MODE=path ;;
    --restore)     MODE=restore ;;
    --move-aside)  MOVE_ASIDE=1 ;;
    -n|--dry-run)  DRY=1 ;;
    -h|--help)     usage; exit 0 ;;
    -*)            die "unknown option: $arg  (try --help)" ;;
    *)             [ -z "$WANT" ] || die "give one profile, not several"; WANT=$arg ;;
  esac
done

if [ "$MODE" = path ]; then printf '%s\n' "$TARGET"; exit 0; fi
[ -d "$CONF_DIR" ] || die "the configs folder is missing next to switch.sh"

# ─── profile table, read from the files themselves ──────────────────────
NUMS=(); SLUGS=(); TITLES=(); BLURBS=(); FILES=()
for f in "$CONF_DIR"/0[1-9]-*.conf; do
  [ -f "$f" ] || continue
  base=$(basename "$f" .conf)
  NUMS+=("${base%%-*}")
  SLUGS+=("${base#*-}")
  FILES+=("$f")
  # Line 2 of each file reads "GHOSTTY · PROFILE 03 · WORKHORSE", line 3 the summary.
  TITLES+=("$(sed -n '2p' "$f" | sed 's/^# ║ *//; s/ *║$//; s/.*·  *//')")
  BLURBS+=("$(sed -n '3p' "$f" | sed 's/^# ║ *//; s/ *║$//')")
done
[ "${#FILES[@]}" -gt 0 ] || die "no profiles found in $CONF_DIR"

list_profiles() {
  local i
  printf '\n%sProfiles%s\n' "$B" "$Z"
  for i in "${!FILES[@]}"; do
    printf '  %s%s%s  %s%-13s%s %s\n' "$B$C" "${NUMS[$i]#0}" "$Z" "$B" "${TITLES[$i]}" "$Z" "${BLURBS[$i]}"
  done
  printf '\n'
}

if [ "$MODE" = list ]; then list_profiles; exit 0; fi

# ─── helpers ────────────────────────────────────────────────────────────
GHOSTTY_BIN=''
for b in ghostty /Applications/Ghostty.app/Contents/MacOS/ghostty "$HOME/Applications/Ghostty.app/Contents/MacOS/ghostty"; do
  if command -v "$b" >/dev/null 2>&1; then GHOSTTY_BIN=$(command -v "$b"); break; fi
done

stamp() { date +%Y%m%d-%H%M%S; }

# A name that is not taken yet, so a backup never overwrites an older one.
unique_path() {
  local cand=$1 n=1
  while [ -e "$cand" ]; do n=$((n + 1)); cand="$1-$n"; done
  printf '%s\n' "$cand"
}

backup_target() {
  [ -f "$TARGET" ] || return 0
  local dest
  dest=$(unique_path "$TARGET.bak-$(stamp)")
  run cp -p "$TARGET" "$dest"
  if [ "$DRY" = 1 ]; then note "would back up your current config to: $dest"; else note "backup of your current config: $dest"; fi
}

# ─── restore ────────────────────────────────────────────────────────────
if [ "$MODE" = restore ]; then
  newest=''
  for f in "$TARGET".bak-*; do
    if [ -f "$f" ]; then newest=$f; fi
  done
  [ -n "$newest" ] || die "no backup found next to $TARGET"
  printf '%sRestoring%s %s\n' "$B" "$Z" "$newest"
  backup_target
  run cp -p "$newest" "$TARGET"
  report restored restore "$TARGET"
  if [ "$DRY" != 1 ]; then note "Reload Ghostty with $RELOAD."; fi
  exit 0
fi

# ─── pick a profile ─────────────────────────────────────────────────────
pick=-1
if [ -z "$WANT" ]; then
  [ -t 0 ] || die "no profile given. Run  ./switch.sh --list  to see them."
  list_profiles
  printf '  Pick a profile [1-%s, q to quit]: ' "${#FILES[@]}"
  read -r WANT || exit 1
  case $WANT in q|Q|'') exit 0 ;; esac
fi

lower=$(printf '%s' "$WANT" | tr '[:upper:]' '[:lower:]')
matches=0
for i in "${!FILES[@]}"; do
  if [ "$lower" = "${NUMS[$i]#0}" ] || [ "$lower" = "${NUMS[$i]}" ] || [ "$lower" = "${SLUGS[$i]}" ]; then
    pick=$i; matches=1; break
  fi
done
if [ "$pick" -lt 0 ]; then
  for i in "${!FILES[@]}"; do
    case ${SLUGS[$i]} in *"$lower"*) pick=$i; matches=$((matches + 1)) ;; esac
  done
  [ "$matches" -le 1 ] || die "\"$WANT\" matches more than one profile; use the number"
fi
[ "$pick" -ge 0 ] || die "no profile called \"$WANT\"  (try --list)"

SRC=${FILES[$pick]}
printf '%sInstalling%s %s%s%s\n' "$B" "$Z" "$B$C" "${TITLES[$pick]}" "$Z"
note "${BLURBS[$pick]}"
if [ "$DRY" = 1 ]; then note "dry run: nothing will be changed"; fi

# ─── install ────────────────────────────────────────────────────────────
run mkdir -p "$TARGET_DIR"
if [ -f "$TARGET" ] && cmp -s "$SRC" "$TARGET"; then
  ok "$TARGET already contains this profile"
else
  backup_target
  run cp "$SRC" "$TARGET"
  report wrote write "$TARGET"
fi

# Other files that would load as well.
for f in ${OTHERS[@]+"${OTHERS[@]}"}; do
  [ -s "$f" ] || continue
  if [ "$MOVE_ASIDE" = 1 ]; then
    run mv "$f" "$(unique_path "$f.disabled-$(stamp)")"
    report "moved aside" "move aside" "$f"
  else
    warn "Ghostty also reads $f"
    note "Its settings stack on top of the profile. To use the profile alone:"
    note "  ./switch.sh $((10#${NUMS[$pick]})) --move-aside      (renames it, nothing is deleted)"
  fi
done

# ─── fonts ──────────────────────────────────────────────────────────────
family=$(sed -n 's/^font-family = "\(.*\)"$/\1/p' "$SRC" | head -n 1)
hint=''
case $family in
  "Geist Mono")    hint='macOS: brew install --cask font-geist-mono     Linux: github.com/vercel/geist-font' ;;
  "Fira Code")     hint='macOS: brew install --cask font-fira-code      Debian/Ubuntu: sudo apt install fonts-firacode' ;;
  "Iosevka")       hint='macOS: brew install --cask font-iosevka        Linux: github.com/be5invis/Iosevka (releases)' ;;
  "IBM Plex Mono") hint='macOS: brew install --cask font-ibm-plex-mono  Debian/Ubuntu: sudo apt install fonts-ibm-plex' ;;
esac
if [ -n "$hint" ]; then
  have_font=unknown
  if [ -n "$GHOSTTY_BIN" ] && [ "$DRY" != 1 ]; then
    fonts=$("$GHOSTTY_BIN" +list-fonts 2>/dev/null || true)
    if [ -n "$fonts" ]; then
      if grep -qiF "$family" <<<"$fonts"; then have_font=yes; else have_font=no; fi
    fi
  fi
  case $have_font in
    yes) ok "font \"$family\" is installed" ;;
    no)  warn "font \"$family\" is not installed; Ghostty uses the built-in JetBrains Mono until it is."
         note "$hint" ;;
    *)   note "font: $family  ($hint)"
         note "Not installed? Ghostty falls back to the built-in JetBrains Mono." ;;
  esac
fi

# ─── validate ───────────────────────────────────────────────────────────
if [ -n "$GHOSTTY_BIN" ] && [ "$DRY" != 1 ]; then
  if out=$("$GHOSTTY_BIN" +validate-config 2>&1); then
    ok "ghostty +validate-config: no problems"
  else
    warn "ghostty +validate-config reported:"
    printf '%s\n' "$out" | head -n 10 | sed 's/^/    /'
  fi
else
  note "Check it with:  ghostty +validate-config"
fi

printf '\n%sNext:%s in Ghostty press %s%s%s to reload.\n' "$B" "$Z" "$B" "$RELOAD" "$Z"
if [ "$OS" = Darwin ]; then
  note "If a changed window transparency does not apply, quit and reopen Ghostty once."
fi
note "Undo any time:  ./switch.sh --restore"
if [ ! -r "${XDG_CONFIG_HOME:-$HOME/.config}/ghostty-zsh/ghostty.zsh" ]; then
  note "Want autocomplete, autosuggestions and syntax colors in the shell too?  ./shell/install.sh"
fi
