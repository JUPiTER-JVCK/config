GHOSTTY PROFILES
================

Five paste-ready Ghostty configs, a zsh layer for autocomplete and friends,
and a small script that switches between the profiles.

Checked against Ghostty 1.3.1 (the newest release tag found), for macOS and
Linux. Ghostty itself was not run while this was built, so after pasting,
run:  ghostty +validate-config


CONTENTS
--------
  1. What is in this folder
  2. Quick start
  3. The five profiles
  4. Autocomplete, suggestions and colored commands
  5. Fonts
  6. When something looks off
  7. What was checked


1. WHAT IS IN THIS FOLDER
-------------------------

    ghostty-profiles/
    ├── configs/
    │   ├── 01-daily-driver.conf   Catppuccin Mocha · JetBrains Mono
    │   ├── 02-glass.conf          Tokyo Night · Geist Mono
    │   ├── 03-workhorse.conf      Gruvbox Dark · Fira Code
    │   ├── 04-cyberdeck.conf      neon · Iosevka
    │   └── 05-zen.conf            Rose Pine · IBM Plex Mono
    ├── shell/
    │   ├── install.sh             sets up the zsh layer
    │   ├── ghostty.zsh            suggestions, colors, Tab menu, history search
    │   └── starship.toml          the prompt
    ├── switch.sh                  puts a profile in place
    ├── guide.html                 the illustrated guide (open it in a browser)
    └── README.md                  this file


2. QUICK START
--------------

Fastest way: the switcher script. Run it in this folder.

    ./switch.sh            pick from a menu
    ./switch.sh 1          or by number (1-5) or name, e.g. glass
    ./switch.sh --restore  put the previous config back
    ./switch.sh 1 -n       only show what would happen

It writes the profile to the right place for your system, backs up what was
there, warns about other config files Ghostty would also read (add
--move-aside to rename them out of the way, nothing is deleted), and tells
you how to reload. If you get "permission denied", run it with bash in
front, as shown below.

    bash switch.sh 1

By hand:

  1. Open a file from configs/ and copy everything. Open Ghostty's config
  file (Cmd+, on macOS, Ctrl+, on Linux), paste over the old content and
  save. Keep a copy of your old settings first. The file lives here:

       macOS   ~/Library/Application Support/com.mitchellh.ghostty/config.ghostty
       Linux   ~/.config/ghostty/config.ghostty

  2. Reload with Cmd+Shift+, (macOS) or Ctrl+Shift+, (Linux). One exception:
     on macOS a changed background-opacity needs a full quit and reopen of
     Ghostty.
  3. Run  ghostty +validate-config  in any terminal. It reports every line
     Ghostty cannot read.


3. THE FIVE PROFILES
--------------------

Not sure which? Take profile 1. It is the simple one: a clean dark theme, a
good built-in font and no key changes. Every config also sets
GHOSTTY_PROFILE, which the zsh layer reads to match its colors.

1  DAILY DRIVER
   Catppuccin Mocha · JetBrains Mono 14
   Everyday work. The simple one to start with.
   Window: 96% opaque (a little see-through), blur 20
   Keys:   Ghostty's default keys
   File:   configs/01-daily-driver.conf  (118 lines)

2  GLASS
   Tokyo Night · Geist Mono 14
   A desktop that shows through, plus a terminal on a hotkey.
   Window: 78% opaque (a little see-through), blur 26
   Keys:   dropdown hotkey Ctrl+`
   File:   configs/02-glass.conf  (130 lines)

3  WORKHORSE
   Gruvbox Dark · Fira Code 13
   Long sessions with many tabs and panes.
   Window: fully opaque
   Keys:   Ctrl+B leader layer
   File:   configs/03-workhorse.conf  (219 lines)

4  CYBERDECK
   Neon on ink · Iosevka 15
   Late-night terminal work with a neon look.
   Window: 90% opaque (a little see-through), blur 14
   Keys:   dropdown hotkey Ctrl+`
   File:   configs/04-cyberdeck.conf  (134 lines)

5  ZEN
   Rose Pine · IBM Plex Mono 15
   Reading logs, writing, and working without interruptions.
   Window: fully opaque
   Keys:   Ghostty's default keys
   File:   configs/05-zen.conf  (108 lines)


4. AUTOCOMPLETE, SUGGESTIONS AND COLORED COMMANDS
-------------------------------------------------

Ghostty has no plugin system. Those features belong to the shell running
inside it, so they come from a small zsh layer: shell/ghostty.zsh. It loads
everything in the order the plugins document, matches the greys and accents
to your profile, and only runs in a shell you type into (editors and scripts
that start zsh in the background are left alone).

    cd shell && ./install.sh

The installer asks before it changes anything and only adds what is missing:
helper tools (zsh, git, fzf, eza, bat, fd, ripgrep, zoxide, Starship)
through Homebrew, apt, dnf, pacman or zypper; five zsh plugins into
~/.local/share/ghostty-zsh/plugins; ghostty.zsh and starship.toml into
~/.config/ghostty-zsh; and one marked block in ~/.zshrc (your old .zshrc is
backed up first). Answer its questions one at a time, and do not paste more
commands behind it.

When it finishes, open a new tab (or run  exec zsh ) and type  gzhelp  for
the cheat sheet.

What you get:

  Suggestions     grey ghost text from your history. Right arrow or End
                  accepts it, Ctrl+Right takes one word, Ctrl+Space takes all
                  of it, Alt+Enter takes it and runs it.
  Syntax colors   valid commands green, unknown words red, quotes yellow.
                  rm -rf * gets a red banner.
  Tab menu        a fuzzy, filterable list with previews (fzf-tab). F1 and F2
                  switch groups.
  Completions     rules for hundreds of extra tools (zsh-completions).
  History search  type part of a command and press Up
                  (zsh-history-substring-search).
  Fuzzy finders   Ctrl+R history, Ctrl+T files, Alt+C folders, each with a
                  preview (fzf).
  Smart cd        z name jumps to the folder you use most, zi picks from a
                  list (zoxide).
  Prompt          two lines with folder, git state, language versions and
                  command time (Starship). A simple prompt appears if Starship
                  is missing.
  Listings        ls, ll, la and lt through eza, previews through bat, search
                  through fd and ripgrep.
  Extras          a shared 50,000-line history, Esc Esc toggles sudo,
                  Ctrl+X Ctrl+E edits the line in $EDITOR, mkcd, up 3, extract
                  and short git aliases.

Switches (set them in ~/.zshrc above the line that loads the layer):

  GZ_VI_MODE=1           vi keys on the command line
  GZ_PROMPT=ghostty      always use this prompt (default: it only replaces zsh's
                         plain stock prompt, so Powerlevel10k and the like stay)
  GZ_PROMPT=keep         never touch the prompt
  GZ_NO_ALIASES=1        skip the ls, git and navigation aliases
  GHOSTTY_ZSH_PLUGINS    folder to load plugins from

Look first:   ./install.sh --dry-run     (prints every step, changes nothing)
Remove:       ./install.sh --uninstall   (--purge also deletes the plugins)

Many Linux systems use bash by default. The layer is for zsh: install zsh,
then run  chsh -s "$(command -v zsh)"  and sign in again.


5. FONTS
--------

Installing the font is optional. Without it Ghostty falls back to JetBrains
Mono, which is built in. See what is installed with:  ghostty +list-fonts

  JetBrains Mono
      macOS   built into Ghostty
      Linux   built into Ghostty
  Geist Mono
      macOS   brew install --cask font-geist-mono
      Linux   github.com/vercel/geist-font
  Fira Code
      macOS   brew install --cask font-fira-code
      Linux   sudo apt install fonts-firacode
  Iosevka
      macOS   brew install --cask font-iosevka
      Linux   github.com/be5invis/Iosevka (Releases)
  IBM Plex Mono
      macOS   brew install --cask font-ibm-plex-mono
      Linux   sudo apt install fonts-ibm-plex


6. WHEN SOMETHING LOOKS OFF
---------------------------

  * The font looks different from the sketch
    The named font is not installed, so Ghostty used JetBrains Mono. Install
    it (section 5), run ghostty +list-fonts to confirm, then reload.

  * Nothing changed after pasting
    Reload (section 2). If it still looks old, another config file is
    stacking on top: run ./switch.sh N --move-aside, or look at the
    effective settings with ghostty +show-config.

  * Not see-through or not blurred
    On macOS quit and reopen Ghostty after changing background-opacity. Blur
    only works on macOS and KDE Plasma. Profiles 3 and 5 are opaque on
    purpose.

  * The dropdown hotkey does nothing
    macOS: allow Ghostty under System Settings, Privacy & Security,
    Accessibility. Pick another chord if another app owns Ctrl+` (VS Code
    does), for example global:ctrl+alt+space. Linux: the dropdown needs a
    Wayland compositor with layer-shell (KDE Plasma, Hyprland, Sway), so not
    GNOME and not X11. The global key works on KDE 5.27 and newer and on
    Hyprland after some setup; Sway has no global hotkeys yet.

  * Ctrl+B does nothing in profile 3
    It is a leader: press it, let go, then press the next key. Press it
    twice to send a real Ctrl+B. Esc leaves resize and scroll mode.

  * Option+letter types odd characters on a Mac
    The profiles make the left Option key act as Alt. Use the right Option
    key for accents and symbols.

  * Ghost text too faint or too bright
    Its color comes from the profile. Check  echo $GHOSTTY_PROFILE . If it
    is empty you are not in a Ghostty window using one of these profiles,
    and the layer falls back to your terminal's bright black.

  * Prompt icons show as boxes
    Ghostty has a Nerd Font symbol set built in, so boxes usually mean you
    are connected from another terminal, or set a font fallback of your own.

  * ssh does not know the terminal type
    The profiles turn on ssh-env and ssh-terminfo, which fix this. If a host
    refuses both, run  TERM=xterm-256color ssh host .

  * I want my old setup back
    ./switch.sh --restore puts the latest backup back; earlier backups stay
    next to it. ./install.sh --uninstall removes the shell layer's block
    from .zshrc.


7. WHAT WAS CHECKED
-------------------

Checked:
  + All 365 settings and 80 keybinds in the five configs against the option
    definitions in the Ghostty 1.3.1 source: names, value types, number
    ranges, key names, actions, key tables, and duplicate or conflicting
    bindings. No errors.
  + The four palettes taken from known themes match the upstream theme
    files; the few intentional differences (cursor colors) are listed in the
    lint report. Text contrast was measured for every profile.
  + The zsh layer ran in a pseudo-terminal under zsh 5.9, with older and
    current tool versions, on a bare machine, with no plugins, in vi mode,
    and once per profile: ghost text, syntax colors, the Tab menu, history
    search, the Esc Esc sudo toggle, the prompt and repeated loading.
  + switch.sh and install.sh pass bash -n and ShellCheck, and were run in
    throwaway home folders: dry run, install, repeat, backup, restore,
    uninstall, and rapid repeated runs that must not overwrite a backup.

Not checked:
  - Ghostty itself was never run while this was built. Fonts, blur,
    titlebars and hotkeys are unconfirmed in the real app.
    ghostty +validate-config is the real test.
  - The macOS paths and Homebrew steps were simulated with fake home folders
    and printed commands; they have not run on a Mac.
  - The dnf, pacman and zypper commands were printed, not run. The apt path
    was exercised.
  - The terminal used for the shell tests is an emulator, not Ghostty, so
    colors were checked by value, not by eye.
  - v1.3.1 is the newest release tag that could be found. Newer versions may
    add options, but nothing here depends on unreleased ones.

